import requests
import json

def emotion_detector(text_to_analyze):
    url = 'https://sn-watson-emotion.labs.skills.network/v1/watson.runtime.nlp.v1/NlpService/EmotionPredict'
    object_json = { "raw_document": { "text": text_to_analyze } }
    headers = {"grpc-metadata-mm-model-id": "emotion_aggregated-workflow_lang_en_stock"}
    res = requests.post(url, json = object_json, headers = headers)
    return res.text
    if res.status_code == 400:
        return {'anger': "None", 'disgust': "None", 'fear': "None", 'joy': "None", 'sadness': "None", 'dominant_emotion': "None"}
    json_res = json.loads(res.text)['emotionPredictions'][0]['emotion']
    anger = json_res['anger']
    disgust = json_res['disgust']
    fear = json_res['fear']
    joy = json_res['joy']
    sadness = json_res['sadness']
    dominant_emotion = ''
    emotions = [anger, disgust, fear, joy, sadness]
    value = max(emotions)
    if anger == value:
        dominant_emotion = 'anger'
    elif disgust == value:
        dominant_emotion = 'disgust'
    elif fear == value:
        dominant_emotion = 'fear'
    elif joy == value:
        dominant_emotion = 'joy'
    elif sadness == value:
        dominant_emotion = 'sadness'

    return {'anger': anger, 'disgust': disgust, 'fear': fear, 'joy': joy, 'sadness': sadness, 'dominant_emotion': dominant_emotion} 


