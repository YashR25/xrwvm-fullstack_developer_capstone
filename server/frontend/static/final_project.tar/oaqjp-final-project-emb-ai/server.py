''' imported Flask, request and render_template from flask module'''
from flask import Flask, request, render_template
from EmotionDetection.emotion_detection import emotion_detector

app = Flask('Emotion Detector')

@app.route('/')
def get_main():
    '''render main index.html file for home (default) root'''
    return render_template('index.html')

@app.route('/emotionDetector')
def get_emotion():
    '''get the emotion based on the text from request using our imported function \
    emotion_detector'''
    text_to_analyze = request.args.get('textToAnalyze')
    res = emotion_detector(text_to_analyze)
    anger = res['anger']
    disgust = res['disgust']
    fear = res['fear']
    joy = res['joy']
    sadness = res['sadness']
    dominant_emotion = res['dominant_emotion']
    if dominant_emotion == 'None':
        return 'Invalid text! Please try again'
    return f"For the given statement, the system response is 'anger': {anger}, \
    'disgust': {disgust}, 'fear': {fear}, 'joy': {joy} and 'sadness': {sadness}. \
    The dominant emotion is {dominant_emotion}."

if __name__ == "__main__":
    app.run(host = '0.0.0.0', port = 5000)
